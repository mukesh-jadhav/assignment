import random
import string
from dataclasses import dataclass, field, fields


def generate_id():
    return "".join(random.choices(string.ascii_uppercase, k=12))

@dataclass(order=True, kw_only=False)
class Camera:
    sort_index: int = field(init=False)
    name: str
    port: int
    fps: int
    active: bool = False
    _id: str = field(default_factory=generate_id, init=False, repr=False)     

    def __post_init__(self):
        self.sort_index = self.fps

if __name__ == "__main__":
    camera1 = Camera(name="Logitech webcam", port=5150, fps=23)
    camera2 = Camera("Hytech 5520 Webcam", 5000, 240)
    camera3 = Camera("Hytech 5520 Webcam", 4000, 240)

    print(id(camera2))
    #print(id(camera2))
    #print(camera3)

    print(camera1 < camera3)
