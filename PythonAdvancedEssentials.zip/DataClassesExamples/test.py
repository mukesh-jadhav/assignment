from dataclasses import dataclass, field
import random
import string 


def generate_id():
    return "".join(random.choices(string.ascii_uppercase, k=12))

@dataclass(order=True, kw_only=False, frozen=True)
class Camera:
    sort_index: int = field(init=False)
    name : str
    port : int
    fps : int
    id: str = field(default_factory=generate_id, repr=False)

    def __post_init__(self):
        self.sort_index = self.fps

if __name__ == "__main__":
    #camera1 = Camera(port= 5150, name="Logitech webcam", fps = 23)
    camera2 = Camera("Hytech 5520 Webcam", 5000, 240)
    camera2.port = 3000
    #camera3 = Camera("Hytech 5520 Webcam", 5000, 240)

    #print(id(camera1))
    #print(id(camera2))
    print(camera2)

    #print(camera1 > camera3)
