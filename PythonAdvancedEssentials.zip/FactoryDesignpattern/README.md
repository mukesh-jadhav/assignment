# 7 The Factory Pattern in Python

This repository contains the code for the The Factory Pattern in Python video on the ArjanCodes channel. Watch the video [here](https://youtu.be/s_4ZrtQs8Do).

The example is about video and audio exporting. In `before.py`, you find the original code. The `after.py` file contains a version where the factory pattern is used.
